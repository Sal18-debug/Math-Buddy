# Multiple-Choice-Quiz-JavaScript
Today we're going to create a multiple choice quiz using JavaScript, in this quiz, the user will have to choose the correct answer out of three choices, in less than 10 seconds, if the user didn't answer the question in 10sec, it will go to the next question automatically, and the question is marked wrong. the user has a progress bar, that shows the total number of question, and also if the user answered a question correctly or not.

Watch The Tutorial On Youtube: 
https://www.youtube.com/watch?v=49pYIMygIcU


